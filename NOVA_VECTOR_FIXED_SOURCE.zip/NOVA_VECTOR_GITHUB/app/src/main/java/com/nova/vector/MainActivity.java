package com.nova.vector;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private EditorView editor;
    private TextView status;
    private static final int REQ_SAVE=21, REQ_OPEN=22, REQ_EXPORT=23, REQ_SVG=24;
    private final int panelColor=0xff171a21;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xff101217);
        getWindow().setNavigationBarColor(0xff101217);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xff171a21);

        HorizontalScrollView topScroll=new HorizontalScrollView(this);
        topScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(6,4,6,4);
        top.setBackgroundColor(0xff101217);
        TextView brand=label("NOVA VECTOR",16,Color.WHITE);
        brand.setTypeface(null,1);
        brand.setPadding(10,12,14,12);
        top.addView(brand);
        addTop(top,"Undo",()->editor.undo());
        addTop(top,"Redo",()->editor.redo());
        addTop(top,"−",()->editor.zoom(.85f));
        addTop(top,"+",()->editor.zoom(1.18f));
        addTop(top,"Save",()->saveProject());
        addTop(top,"Open",()->openProject());
        addTop(top,"PNG",()->exportPng());
        addTop(top,"SVG",()->exportSvg());
        topScroll.addView(top);
        root.addView(topScroll,new LinearLayout.LayoutParams(-1,-2));

        editor=new EditorView(this);
        root.addView(editor,new LinearLayout.LayoutParams(-1,0,1));

        status=label("Ready • Choose a tool below",12,0xffc4cad5);
        status.setPadding(12,7,12,7);
        root.addView(status,new LinearLayout.LayoutParams(-1,-2));

        HorizontalScrollView toolScroll=new HorizontalScrollView(this);
        toolScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tools=new LinearLayout(this);
        tools.setPadding(5,5,5,5);
        tools.setBackgroundColor(panelColor);
        String[] names={"Select","Move","Pen","Pencil","Brush","Eraser","Rect","Ellipse","Line","Star","Text"};
        for(String n:names) addTool(tools,n);
        toolScroll.addView(tools);
        root.addView(toolScroll,new LinearLayout.LayoutParams(-1,-2));

        HorizontalScrollView panelScroll=new HorizontalScrollView(this);
        panelScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout panels=new LinearLayout(this);
        panels.setPadding(5,2,5,5);
        panels.setBackgroundColor(panelColor);
        String[] tabs={"Color","Brush size","Opacity","Layers","Files"};
        for(String n:tabs) addPanelButton(panels,n);
        panelScroll.addView(panels);
        root.addView(panelScroll,new LinearLayout.LayoutParams(-1,-2));

        setContentView(root);
        editor.setTool("Pencil");
    }

    private TextView label(String s,int size,int c){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(c); return t;
    }
    private void styleButton(TextView t){
        t.setGravity(Gravity.CENTER); t.setTextColor(Color.WHITE); t.setTextSize(12);
        t.setPadding(12,11,12,11); t.setBackgroundColor(0xff303744);
    }
    private void addTop(LinearLayout p,String s,Runnable r){
        TextView t=label(s,12,Color.WHITE); styleButton(t);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2); lp.setMargins(3,2,3,2);
        p.addView(t,lp); t.setOnClickListener(v->{try{r.run();}catch(Exception e){showError(e);}});
    }
    private void addTool(LinearLayout p,String s){
        TextView t=label(s,12,Color.WHITE); styleButton(t);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2); lp.setMargins(3,2,3,2);
        p.addView(t,lp);
        t.setOnClickListener(v->{
            if(s.equals("Text")){addTextDialog();return;}
            String tool=s.equals("Rect")?"Rectangle":s;
            editor.setTool(tool); status.setText("Active tool: "+tool);
        });
    }
    private void addPanelButton(LinearLayout p,String s){
        TextView t=label(s,12,Color.WHITE); styleButton(t);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2); lp.setMargins(3,2,3,2);
        p.addView(t,lp); t.setOnClickListener(v->showPanel(s));
    }
    private void addTextDialog(){
        EditText e=new EditText(this); e.setSingleLine(false); e.setText("Your text");
        new AlertDialog.Builder(this).setTitle("Add text").setView(e)
            .setPositiveButton("Add",(d,w)->editor.addText(e.getText().toString()))
            .setNegativeButton("Cancel",null).show();
    }
    private void showPanel(String tab){
        if(tab.equals("Color")){
            String[] names={"White","Black","Red","Orange","Yellow","Green","Blue","Purple"};
            int[] colors={Color.WHITE,Color.BLACK,Color.RED,0xffff8a00,Color.YELLOW,Color.GREEN,Color.BLUE,0xff9c27b0};
            new AlertDialog.Builder(this).setTitle("Choose color").setItems(names,(d,i)->editor.setColor(colors[i],false)).show();
        } else if(tab.equals("Brush size")||tab.equals("Opacity")){
            SeekBar seek=new SeekBar(this); seek.setMax(tab.equals("Opacity")?100:79); seek.setProgress(tab.equals("Opacity")?100:7);
            new AlertDialog.Builder(this).setTitle(tab).setView(seek)
                .setPositiveButton("Apply",(d,w)->{if(tab.equals("Opacity"))editor.setOpacity(seek.getProgress());else editor.setBrushSize(seek.getProgress()+1);}).setNegativeButton("Cancel",null).show();
        } else if(tab.equals("Layers")){
            String[] a={"Add layer","Delete current layer","Rename current layer","Toggle current layer"};
            new AlertDialog.Builder(this).setTitle("Layers").setItems(a,(d,i)->{
                if(i==0)editor.addLayer(); if(i==1)editor.deleteLayer();
                if(i==2){EditText e=new EditText(this);new AlertDialog.Builder(this).setTitle("Layer name").setView(e).setPositiveButton("Rename",(x,y)->editor.renameLayer(e.getText().toString())).show();}
                if(i==3)editor.toggleLayer();
            }).show();
        } else {
            String[] a={"New project","Open project","Save project","Export PNG","Export SVG"};
            new AlertDialog.Builder(this).setTitle("Files").setItems(a,(d,i)->{
                if(i==0)editor.clearProject(); if(i==1)openProject(); if(i==2)saveProject(); if(i==3)exportPng(); if(i==4)exportSvg();
            }).show();
        }
    }
    private void saveProject(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"NovaVectorProject.nova");startActivityForResult(i,REQ_SAVE);}
    private void openProject(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_OPEN);}
    private void exportPng(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("image/png");i.putExtra(Intent.EXTRA_TITLE,"NovaVector.png");startActivityForResult(i,REQ_EXPORT);}
    private void exportSvg(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("image/svg+xml");i.putExtra(Intent.EXTRA_TITLE,"NovaVector.svg");startActivityForResult(i,REQ_SVG);}
    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data); if(c!=RESULT_OK||data==null)return;
        try{
            Uri u=data.getData();
            if(r==REQ_SAVE){try(OutputStream o=getContentResolver().openOutputStream(u)){o.write(editor.toJson().getBytes("UTF-8"));}}
            else if(r==REQ_OPEN){try(InputStream in=getContentResolver().openInputStream(u)){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[4096];int n;while((n=in.read(x))>0)b.write(x,0,n);editor.loadJson(b.toString("UTF-8"));}}
            else if(r==REQ_EXPORT){Bitmap b=editor.renderBitmap(1600,1200);try(OutputStream o=getContentResolver().openOutputStream(u)){b.compress(Bitmap.CompressFormat.PNG,100,o);}}
            else if(r==REQ_SVG){try(OutputStream o=getContentResolver().openOutputStream(u)){o.write(editor.toSvg().getBytes("UTF-8"));}}
        }catch(Exception e){showError(e);}
    }
    private void showError(Exception e){new AlertDialog.Builder(this).setTitle("NOVA VECTOR").setMessage(e.getMessage()==null?"Operation failed":e.getMessage()).setPositiveButton("OK",null).show();}
}
