package com.nova.vector;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import org.json.*;
import java.util.*;

public class EditorView extends View {
    static class Obj {
        String type="path",text="",layer="Layer 1";
        Path path=new Path(); int color=Color.WHITE; float width=8,opacity=1,x,y;
        boolean visible=true;
    }
    private final ArrayList<Obj> objects=new ArrayList<>();
    private final Stack<String> undo=new Stack<>(),redo=new Stack<>();
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private String tool="Pencil",layer="Layer 1";
    private int color=Color.WHITE,layerNo=1;
    private float brush=8,opacity=1,scale=1,dx,dy,startX,startY;
    private Obj current,selected;
    private boolean moving=false;

    public EditorView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    private void checkpoint(){undo.push(toJson());if(undo.size()>40)undo.remove(0);redo.clear();}
    public void undo(){if(!undo.empty()){redo.push(toJson());loadJson(undo.pop());}}
    public void redo(){if(!redo.empty()){undo.push(toJson());loadJson(redo.pop());}}
    public void clearProject(){checkpoint();objects.clear();selected=null;invalidate();}
    public void setTool(String t){tool=t;invalidate();}
    public void zoom(float f){scale=Math.max(.25f,Math.min(5,scale*f));invalidate();}
    public void setColor(int c,boolean stroke){color=c;invalidate();}
    public void setOpacity(int v){opacity=Math.max(0,Math.min(100,v))/100f;if(selected!=null)selected.opacity=opacity;invalidate();}
    public void setBrushSize(int v){brush=Math.max(1,v);invalidate();}
    public void addLayer(){layer="Layer "+(++layerNo);}
    public void deleteLayer(){checkpoint();for(int i=objects.size()-1;i>=0;i--)if(objects.get(i).layer.equals(layer))objects.remove(i);selected=null;invalidate();}
    public void renameLayer(String n){if(n==null||n.trim().isEmpty())return;for(Obj o:objects)if(o.layer.equals(layer))o.layer=n;layer=n;invalidate();}
    public void toggleLayer(){for(Obj o:objects)if(o.layer.equals(layer))o.visible=!o.visible;invalidate();}
    public void addText(String s){if(s==null||s.trim().isEmpty())return;checkpoint();Obj o=new Obj();o.type="text";o.text=s;o.x=100;o.y=160;o.color=color;o.layer=layer;objects.add(o);selected=o;invalidate();}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);c.drawColor(0xff252a33);float w=getWidth(),h=getHeight();
        c.save();c.translate(dx,dy);c.scale(scale,scale);
        paint.setColor(0xffeeeeee);paint.setStyle(Paint.Style.FILL);c.drawRect(12,12,w-12,h-12,paint);
        c.save();c.clipRect(12,12,w-12,h-12);
        for(Obj o:objects)drawObj(c,o);
        if(selected!=null&&tool.equals("Select")){RectF b=bounds(selected);paint.setColor(0xff168cff);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2);c.drawRect(b,paint);}
        c.restore();c.restore();
    }
    private void drawObj(Canvas c,Obj o){
        if(!o.visible)return;
        paint.setAlpha((int)(255*Math.max(0,Math.min(1,o.opacity))));
        paint.setColor(o.color);paint.setStrokeWidth(o.width);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
        if(o.type.equals("text")){paint.setStyle(Paint.Style.FILL);paint.setTextSize(48);c.drawText(o.text,o.x,o.y,paint);}
        else {paint.setStyle(Paint.Style.STROKE);c.drawPath(o.path,paint);}
        paint.setAlpha(255);
    }
    private RectF bounds(Obj o){if(o.type.equals("text")){paint.setTextSize(48);return new RectF(o.x,o.y-48,o.x+paint.measureText(o.text),o.y+8);}RectF r=new RectF();o.path.computeBounds(r,true);return r;}
    private Obj hit(float x,float y){for(int i=objects.size()-1;i>=0;i--){Obj o=objects.get(i);if(o.visible&&bounds(o).contains(x,y))return o;}return null;}
    @Override public boolean onTouchEvent(MotionEvent e){
        float x=(e.getX()-dx)/scale,y=(e.getY()-dy)/scale;
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            startX=x;startY=y;moving=false;current=null;
            if(tool.equals("Select")||tool.equals("Move")){
                selected=hit(x,y);
                if(selected!=null&&tool.equals("Move")){checkpoint();moving=true;}
                invalidate();return true;
            }
            if(isFreehand()||isShape()){
                checkpoint();current=new Obj();current.type="path";current.color=tool.equals("Eraser")?Color.WHITE:color;
                current.width=tool.equals("Eraser")?brush*2:brush;current.opacity=opacity;current.layer=layer;
                current.path.moveTo(x,y);objects.add(current);invalidate();return true;
            }
            return true;
        }
        if(e.getAction()==MotionEvent.ACTION_MOVE){
            if(moving&&selected!=null){float ox=x-startX,oy=y-startY;Matrix m=new Matrix();m.setTranslate(ox,oy);if(selected.type.equals("text")){selected.x+=ox;selected.y+=oy;}else selected.path.transform(m);startX=x;startY=y;invalidate();return true;}
            if(current!=null){if(isFreehand())current.path.lineTo(x,y);else buildShape(current.path,startX,startY,x,y);invalidate();return true;}
        }
        if(e.getAction()==MotionEvent.ACTION_UP){current=null;moving=false;invalidate();return true;}
        return true;
    }
    private boolean isFreehand(){return tool.equals("Pencil")||tool.equals("Pen")||tool.equals("Brush")||tool.equals("Eraser");}
    private boolean isShape(){return tool.equals("Rectangle")||tool.equals("Ellipse")||tool.equals("Line")||tool.equals("Star");}
    private void buildShape(Path path,float x1,float y1,float x2,float y2){
        path.reset();
        if(tool.equals("Rectangle"))path.addRect(Math.min(x1,x2),Math.min(y1,y2),Math.max(x1,x2),Math.max(y1,y2),Path.Direction.CW);
        else if(tool.equals("Ellipse"))path.addOval(Math.min(x1,x2),Math.min(y1,y2),Math.max(x1,x2),Math.max(y1,y2),Path.Direction.CW);
        else if(tool.equals("Line")){path.moveTo(x1,y1);path.lineTo(x2,y2);}
        else if(tool.equals("Star")){float cx=(x1+x2)/2,cy=(y1+y2)/2,rx=Math.abs(x2-x1)/2,ry=Math.abs(y2-y1)/2;for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float r=i%2==0?1:.42f;float px=cx+(float)Math.cos(a)*rx*r,py=cy+(float)Math.sin(a)*ry*r;if(i==0)path.moveTo(px,py);else path.lineTo(px,py);}path.close();}
    }
    public Bitmap renderBitmap(int w,int h){Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(Color.WHITE);float sx=w/(float)Math.max(1,getWidth()),sy=h/(float)Math.max(1,getHeight());c.scale(sx,sy);for(Obj o:objects)drawObj(c,o);return b;}
    private JSONArray pathPoints(Path path){
        JSONArray a=new JSONArray();PathMeasure pm=new PathMeasure(path,false);
        do{float len=pm.getLength();int count=Math.max(2,(int)(len/4)+1);float[] pos=new float[2];for(int i=0;i<count;i++){pm.getPosTan(len*i/(count-1),pos,null);JSONArray pt=new JSONArray();pt.put(pos[0]);pt.put(pos[1]);a.put(pt);}}while(pm.nextContour());return a;
    }
    public String toJson(){
        try{JSONArray a=new JSONArray();for(Obj o:objects){JSONObject j=new JSONObject();j.put("type",o.type);j.put("text",o.text);j.put("color",o.color);j.put("width",o.width);j.put("opacity",o.opacity);j.put("x",o.x);j.put("y",o.y);j.put("layer",o.layer);j.put("points",pathPoints(o.path));a.put(j);}JSONObject root=new JSONObject();root.put("format","NOVA_VECTOR");root.put("version",2);root.put("objects",a);return root.toString(2);}catch(Exception e){return "{}";}
    }
    public void loadJson(String s){
        try{JSONObject root=new JSONObject(s);JSONArray a=root.getJSONArray("objects");objects.clear();for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);Obj o=new Obj();o.type=j.optString("type","path");o.text=j.optString("text","");o.color=j.optInt("color",Color.BLACK);o.width=(float)j.optDouble("width",4);o.opacity=(float)j.optDouble("opacity",1);o.x=(float)j.optDouble("x",0);o.y=(float)j.optDouble("y",0);o.layer=j.optString("layer","Layer 1");JSONArray pts=j.optJSONArray("points");if(pts!=null&&pts.length()>0){for(int k=0;k<pts.length();k++){JSONArray pt=pts.getJSONArray(k);float px=(float)pt.getDouble(0),py=(float)pt.getDouble(1);if(k==0)o.path.moveTo(px,py);else o.path.lineTo(px,py);}}objects.add(o);}selected=null;invalidate();}catch(Exception e){throw new IllegalArgumentException("Invalid NOVA project",e);}
    }
    public String toSvg(){
        StringBuilder s=new StringBuilder("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1600\" height=\"1200\" viewBox=\"0 0 1600 1200\">");
        for(Obj o:objects){if(!o.visible)continue;if(o.type.equals("text"))s.append("<text x=\"").append(o.x).append("\" y=\"").append(o.y).append("\" fill=\"").append(String.format("#%06X",0xFFFFFF&o.color)).append("\" opacity=\"").append(o.opacity).append("\">").append(escape(o.text)).append("</text>");}
        return s.append("</svg>").toString();
    }
    private String escape(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
}
