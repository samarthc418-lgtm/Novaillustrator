# NOVA VECTOR

**Created & Published by Samarth Chougule**

A new Java-based Android vector editor repository.

## Build from GitHub
1. Create a new GitHub repository.
2. Upload the contents of this ZIP to the repository root (keep `.github`).
3. Push to `main` or `master`, or run **Actions → Build NOVA VECTOR APK → Run workflow**.
4. Open the completed workflow and download the `NOVA-VECTOR-debug-apk` artifact.

## Build locally
Requires JDK 17, Android SDK Platform 35 and Gradle 8.9+:
```bash
gradle :app:assembleDebug
```

## Current implementation status
Implemented foundation: dark editor UI, drawing gestures for freehand paths and basic geometric tools, text insertion, basic color/opacity/brush-size controls, layer grouping controls, undo/redo snapshots, JSON project save/open through Android Storage Access Framework, PNG export, and basic SVG text export.

Not yet implemented: true editable Bezier node/handle model, full blend-mode compositor, full gradient-stop editor, image import/adjustment pipeline, texture engine, custom font importer, complete layer/object selection and transform handles, full-fidelity path serialization, JPG export, and exhaustive device testing. The SVG exporter currently serializes text only; project JSON currently does not preserve path geometry. These features must not be represented as complete.

## Project identity
- App: NOVA VECTOR
- Package: `com.nova.vector`
- Language: Java
- Minimum SDK: 23
- Target/compile SDK: 35
